﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.seniorRadioButton = new System.Windows.Forms.RadioButton();
            this.juniorRadioButton = new System.Windows.Forms.RadioButton();
            this.sophomoreRadioButton = new System.Windows.Forms.RadioButton();
            this.freshmanRadioButton = new System.Windows.Forms.RadioButton();
            this.classLabel = new System.Windows.Forms.Label();
            this.regTimeLabel = new System.Windows.Forms.Label();
            this.regTimeButton = new System.Windows.Forms.Button();
            this.regTimeOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(105, 18);
            this.lastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(88, 20);
            this.lastNameLabel.TabIndex = 0;
            this.lastNameLabel.Text = "Last name:";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(202, 14);
            this.lastNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(148, 26);
            this.lastNameTextBox.TabIndex = 1;
            // 
            // seniorRadioButton
            // 
            this.seniorRadioButton.AutoSize = true;
            this.seniorRadioButton.Location = new System.Drawing.Point(170, 95);
            this.seniorRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.seniorRadioButton.Name = "seniorRadioButton";
            this.seniorRadioButton.Size = new System.Drawing.Size(80, 24);
            this.seniorRadioButton.TabIndex = 2;
            this.seniorRadioButton.TabStop = true;
            this.seniorRadioButton.Text = "Senior";
            this.seniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // juniorRadioButton
            // 
            this.juniorRadioButton.AutoSize = true;
            this.juniorRadioButton.Location = new System.Drawing.Point(170, 131);
            this.juniorRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.juniorRadioButton.Name = "juniorRadioButton";
            this.juniorRadioButton.Size = new System.Drawing.Size(77, 24);
            this.juniorRadioButton.TabIndex = 3;
            this.juniorRadioButton.TabStop = true;
            this.juniorRadioButton.Text = "Junior";
            this.juniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadioButton
            // 
            this.sophomoreRadioButton.AutoSize = true;
            this.sophomoreRadioButton.Location = new System.Drawing.Point(170, 166);
            this.sophomoreRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sophomoreRadioButton.Name = "sophomoreRadioButton";
            this.sophomoreRadioButton.Size = new System.Drawing.Size(117, 24);
            this.sophomoreRadioButton.TabIndex = 4;
            this.sophomoreRadioButton.TabStop = true;
            this.sophomoreRadioButton.Text = "Sophomore";
            this.sophomoreRadioButton.UseVisualStyleBackColor = true;
            // 
            // freshmanRadioButton
            // 
            this.freshmanRadioButton.AutoSize = true;
            this.freshmanRadioButton.Location = new System.Drawing.Point(170, 202);
            this.freshmanRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.freshmanRadioButton.Name = "freshmanRadioButton";
            this.freshmanRadioButton.Size = new System.Drawing.Size(106, 24);
            this.freshmanRadioButton.TabIndex = 5;
            this.freshmanRadioButton.TabStop = true;
            this.freshmanRadioButton.Text = "Freshman";
            this.freshmanRadioButton.UseVisualStyleBackColor = true;
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(183, 71);
            this.classLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(52, 20);
            this.classLabel.TabIndex = 6;
            this.classLabel.Text = "Class:";
            // 
            // regTimeLabel
            // 
            this.regTimeLabel.AutoSize = true;
            this.regTimeLabel.Location = new System.Drawing.Point(98, 351);
            this.regTimeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.regTimeLabel.Name = "regTimeLabel";
            this.regTimeLabel.Size = new System.Drawing.Size(260, 20);
            this.regTimeLabel.TabIndex = 7;
            this.regTimeLabel.Text = "The earliest time you can register is:";
            // 
            // regTimeButton
            // 
            this.regTimeButton.Location = new System.Drawing.Point(154, 254);
            this.regTimeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.regTimeButton.Name = "regTimeButton";
            this.regTimeButton.Size = new System.Drawing.Size(147, 35);
            this.regTimeButton.TabIndex = 8;
            this.regTimeButton.Text = "Find Reg. Time";
            this.regTimeButton.UseVisualStyleBackColor = true;
            this.regTimeButton.Click += new System.EventHandler(this.regTimeButton_Click);
            // 
            // regTimeOutputLabel
            // 
            this.regTimeOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regTimeOutputLabel.Location = new System.Drawing.Point(83, 395);
            this.regTimeOutputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.regTimeOutputLabel.Name = "regTimeOutputLabel";
            this.regTimeOutputLabel.Size = new System.Drawing.Size(293, 32);
            this.regTimeOutputLabel.TabIndex = 9;
            this.regTimeOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 462);
            this.Controls.Add(this.regTimeOutputLabel);
            this.Controls.Add(this.regTimeButton);
            this.Controls.Add(this.regTimeLabel);
            this.Controls.Add(this.classLabel);
            this.Controls.Add(this.freshmanRadioButton);
            this.Controls.Add(this.sophomoreRadioButton);
            this.Controls.Add(this.juniorRadioButton);
            this.Controls.Add(this.seniorRadioButton);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.RadioButton seniorRadioButton;
        private System.Windows.Forms.RadioButton juniorRadioButton;
        private System.Windows.Forms.RadioButton sophomoreRadioButton;
        private System.Windows.Forms.RadioButton freshmanRadioButton;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.Label regTimeLabel;
        private System.Windows.Forms.Button regTimeButton;
        private System.Windows.Forms.Label regTimeOutputLabel;
    }
}

